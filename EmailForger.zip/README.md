A application to email anyone with just a email and password without needing 2fact passwords.
To install the prgram just extract its contents into a folder anywhere on your pc, i would 
recomend doing so in your desktop as it is easyer to find, run the .exe and the program should startup.
When running the program for the frist time it might ask to install .net / it should send you to a website by microsoft to download the needed version
